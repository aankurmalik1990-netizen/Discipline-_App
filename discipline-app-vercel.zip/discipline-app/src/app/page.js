"use client";
import DisciplineApp from "./DisciplineApp";

export default function Page() {
  return <DisciplineApp />;
}
