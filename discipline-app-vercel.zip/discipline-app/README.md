# 🏫 DISCIPLINE APP — Vercel Deploy Guide

## Step-by-Step Instructions (5 minutes)

---

### STEP 1 — GitHub Account बनाएं (already है तो skip करें)
1. **github.com** पर जाएं
2. "Sign up" पर click करें
3. Free account बनाएं

---

### STEP 2 — Files Upload करें GitHub पर
1. **github.com** पर login करें
2. **"New repository"** button दबाएं (+ icon, top right)
3. Repository name: `discipline-app`
4. **"Create repository"** दबाएं
5. **"uploading an existing file"** link पर click करें
6. इस ZIP के सभी files को **drag & drop** करें
7. **"Commit changes"** दबाएं

---

### STEP 3 — Vercel पर Deploy करें
1. **vercel.com** पर जाएं
2. **"Sign up with GitHub"** से login करें
3. **"New Project"** दबाएं
4. अपना `discipline-app` repository select करें
5. **"Deploy"** दबाएं — बस! ✅

---

### STEP 4 — Link मिलेगी
Deploy होने के बाद Vercel आपको एक link देगा जैसे:
```
https://discipline-app-xyz.vercel.app
```

यह link किसी को भी share करें — **phone, tablet, computer** सब पर चलेगी!

---

## 📱 Phone पर Install करें (Home Screen)

### Android:
1. Chrome में app का link खोलें
2. Browser menu (3 dots) → **"Add to Home Screen"**
3. App icon phone पर आ जाएगा!

### iPhone:
1. Safari में link खोलें
2. Share button → **"Add to Home Screen"**
3. Done!

---

## ✅ Features
- Class 9D के 49 छात्र पहले से loaded हैं
- 6 प्रकार के violation messages (हिंदी में)
- WhatsApp direct message to parents
- Semester violation records
- Data permanently saved रहता है

---

**किसी भी problem के लिए Claude से पूछें!**
